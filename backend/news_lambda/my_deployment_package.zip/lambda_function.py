import json
import requests
import os

def write_to_database(category, articles):
    if not articles:
        return 
    
def call_news_url(category, url):
    
    result = None
    
    try:
        result = requests.get(url).json()
        print(f"{category} articles count: ", len(result['articles']))
        for i in result['articles']:
            print(i['source']['name'])
    except Exception as e:
        print(f"error fetching {category}: ", e )
        
    return result

    
def lambda_handler(event, context):
    
    NEWS_API_KEY = os.environ["NEWS_API_KEY"]
    
    # get general top headlines
    category = "topHeadlines"
    url_top_headlines = f'https://newsapi.org/v2/top-headlines?country=us&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_top_headlines)
    write_to_database(category, articles_list)
   
    # get business articles
    category = "business"
    url_business = f'https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    # get entertainment articles
    category = "entertainment"
    url_entertainment = f'https://newsapi.org/v2/top-headlines?country=us&category=entertainment&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    # get health articles
    category = "health"
    url_health = f'https://newsapi.org/v2/top-headlines?country=us&category=health&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    # get scieence articles
    category = "science"
    url_health = f'https://newsapi.org/v2/top-headlines?country=us&category=science&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    # get sports articles
    category = "sports"
    url_health = f'https://newsapi.org/v2/top-headlines?country=us&category=sports&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    # get technology articles
    category = "technology"
    url_health = f'https://newsapi.org/v2/top-headlines?country=us&category=technology&apiKey={NEWS_API_KEY}'
    articles_list = call_news_url(category, url_business)
    write_to_database(category, articles_list)
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
